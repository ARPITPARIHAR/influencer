<!-- resources/views/frontend/show.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Data</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}"> <!-- Include your CSS -->
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f4f4f4;
        }
        img {
            max-width: 150px;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Form Data</h1>

        <table>
            <thead>
                <tr>
                    <th>S.N.</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Contact Number</th>
                    <th>Social Media</th>
                    <th>Content Types</th>
                    <th>Thumbnail Image</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>
                @foreach($formData as $index => $form)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $form->first_name }}</td>
                        <td>{{ $form->last_name }}</td>
                        <td>{{ $form->email }}</td>
                        <td>{{ $form->contact_number }}</td>
                        <td>
                            @foreach(json_decode($form->social_media, true) as $platform => $handle)
                                <div><strong>{{ ucfirst($platform) }}:</strong> {{ $handle }}</div>
                            @endforeach
                        </td>
                        <td>
                            @foreach(explode(',', $form->content_types) as $type)
                                <div>{{ $type }}</div>
                            @endforeach
                        </td>
                        <td>
                            @if($form->thumbnail_img)
                                <img src="{{ $form->thumbnail_img }}" alt="Thumbnail Image">
                            @else
                                No image uploaded
                            @endif
                        </td>
                        <td>
                            <form action="" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>
